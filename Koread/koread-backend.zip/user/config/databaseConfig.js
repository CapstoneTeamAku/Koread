const databaseConfig = {
    host : '3.39.132.224' ,
    port : 3306,
    user : 'mk' ,
    password : 'Panda_1247' ,
    database : 'book_db',
    waitForConnections : true ,
    connectionLimit : 10,
    queueLimit : 0
}

module.exports = databaseConfig;